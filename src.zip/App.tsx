import UsersListTile from "./components/UsersListTile.1"
import './App.css'
import 'bootstrap/dist/css/bootstrap.css'

function App() {
  return (
    <div>
      <UsersListTile/>
    </div>
  )
}

export default App
