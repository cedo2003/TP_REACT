import { useState } from "react";
import img1 from "../assets/cedo1.jpeg";
import img2 from "../assets/cedo2.jpeg";
import img3 from "../assets/cedo3.jpeg";

function UsersListTile() {
   
    const [usersList, setUsersList] = useState([
        {
            id: 1,
            name: "HOUNMADJAI Cedric",
            email: "junior@gmail.com",
            imgurl: img1
        },
        {
            id: 2,
            name: "ODJO Benhila",
            email: "benhilan@gmail.com",
            imgurl: img2
        },
        {
            id: 3,
            name: "LeProf de REACT",
            email: "Maxime@gmail.com",
            imgurl: img3
        }
        
    ]);
}
export default UsersListTile;
