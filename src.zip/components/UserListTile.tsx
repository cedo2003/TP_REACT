import { useState } from "react";

function UserListTile(props: any) {
    const [formData, setFormData] = useState({
        name: props.user.name,
        email: props.user.email,
        imgurl: props.user.imgurl
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        // Envoyer les données modifiées ici (formData)
    };

    return (
        <>
            <h3 className="h3">Active User:</h3>
            
            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label htmlFor="name" className="form-label">Name</label>
                    <input type="text" className="form-control" id="name" name="name" value={formData.name} onChange={handleChange} />
                </div>
                <div className="mb-3">
                    <label htmlFor="email" className="form-label">Email address</label>
                    <input type="email" className="form-control" id="email" name="email" value={formData.email} onChange={handleChange} />
                </div>
                <div className="mb-3">
                    <label htmlFor="imgurl" className="form-label">Image URL</label>
                    <input type="text" className="form-control" id="imgurl" name="imgurl" value={formData.imgurl} onChange={handleChange} />
                </div>
                <button type="submit" className="btn btn-primary">Submit</button>
            </form>
        </>
    );
}

export default UserListTile;
